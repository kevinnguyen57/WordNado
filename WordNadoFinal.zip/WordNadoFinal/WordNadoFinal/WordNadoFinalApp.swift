//
//  WordNadoFinalApp.swift
//  WordNadoFinal
//
//  Created by Kevin Nguyen on 5/17/23.
//

import SwiftUI

@main
struct WordNadoFinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
